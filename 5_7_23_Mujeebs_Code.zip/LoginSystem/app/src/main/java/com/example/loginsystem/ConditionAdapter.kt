package com.example.loginsystem

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class ConditionAdapter(context: Context) : ArrayAdapter<String>(context, 0) {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var conditionList = listOf<String>()

    fun setData(conditions: List<String>) {
        conditionList = conditions
        notifyDataSetChanged()
    }

    override fun getCount(): Int {
        return conditionList.size
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        val holder: ViewHolder
        if (view == null) {
            view = inflater.inflate(R.layout.condition_item, parent, false)
            holder = ViewHolder(view)
            view.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }

        val condition = conditionList[position]
        holder.conditionTextView.text = condition

        return view!!
    }

    private class ViewHolder(view: View) {
        val conditionTextView: TextView = view.findViewById(R.id.conditionTextView)
    }
}
