package com.example.loginsystem

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore

class Feedback : AppCompatActivity() {
    private val firestore = FirebaseFirestore.getInstance()
    private val feedbackCollection = firestore.collection("Feedback")

    private lateinit var SubjectEditText: EditText
    private lateinit var usernameEditText: EditText
    private lateinit var feedbackEditText: EditText
    private lateinit var saveButton: Button

    private lateinit var userData: MutableList<String>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        setContentView(R.layout.activity_feedback)

        SubjectEditText = findViewById(R.id.FullName_text)
        usernameEditText = findViewById(R.id.user_nametext)
        feedbackEditText = findViewById(R.id.multiline)
        saveButton = findViewById(R.id.Submitbutton)

        userData = loginpage.adminData
        displayUserData()

        saveButton.setOnClickListener {
            submitFeedback()
        }
    }
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, Homepage::class.java)
        startActivity(intent)
        finish()
    }

    private fun displayUserData() {
        usernameEditText.setText(userData.getOrNull(0) ?: "")
    }

    private fun submitFeedback() {
        val feedbackText = feedbackEditText.text.toString()
        val username = userData.getOrNull(0) ?: ""
        val Subject = SubjectEditText.text.toString()

        if (feedbackText.isNotEmpty()) {
            val feedbackData = hashMapOf(
                "feedback" to feedbackText,
                "user_name" to username,
                "subject" to Subject,
                "status" to "Pending"
            )
            feedbackCollection.add(feedbackData)
                .addOnSuccessListener {
                    Toast.makeText(
                        this@Feedback,
                        "Thank you, for submitting Feedback",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish()
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Error submitting feedback: ${e.message}", e)
                    Toast.makeText(
                        this@Feedback,
                        "Failed to submit feedback. Please try again later.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        } else {
            Toast.makeText(this@Feedback, "Please enter your feedback", Toast.LENGTH_SHORT).show()
        }


    }
}