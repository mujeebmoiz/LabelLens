package com.example.loginsystem

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore

class EditDocument : AppCompatActivity() {
    private lateinit var collectionNameTextView: TextView
    private lateinit var documentNameTextView: TextView
    private lateinit var saveButton: Button
    private lateinit var deleteButton: Button
    private lateinit var selectedCollection: String
    private lateinit var selectedDocument: String
    private val db = FirebaseFirestore.getInstance()
    val selectedCollectionPage = selectedcollection()

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, selectedcollection::class.java)
        startActivity(intent)
        finish()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_edit_document)

        selectedCollection = intent.getStringExtra("selectedCondition").toString()
        selectedDocument = intent.getStringExtra("selectedDocumentName").toString()

        collectionNameTextView = findViewById(R.id.collectioname)
        documentNameTextView = findViewById(R.id.documentname)
        saveButton = findViewById(R.id.Save)
        deleteButton = findViewById(R.id.DeleteAllergy)
        val newName = findViewById<EditText>(R.id.NewName)



        collectionNameTextView.text = "Condition Name: ".plus( selectedCollection)

        documentNameTextView.text = "Original Name: ".plus(selectedDocument)

        saveButton.setOnClickListener {
            val updatedDocumentName = newName.text.toString()
            if (updatedDocumentName.isNotEmpty()) {
                updateDocumentName(updatedDocumentName)
                val intent = Intent(this@EditDocument, ConditionsCollection::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter an allergy name", Toast.LENGTH_SHORT).show()
            }
        }

        deleteButton.setOnClickListener {
            deleteDocument()
            val intent = Intent(this@EditDocument, ConditionsCollection::class.java)
            startActivity(intent)
        }
    }
    private fun updateDocumentName(updatedName: String) {
        val oldName = selectedDocument

        db.collection(selectedCollection)
            .whereEqualTo("name", oldName)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    // Update each document found by the query
                    db.collection(selectedCollection).document(document.id)
                        .update("name", updatedName)
                        .addOnSuccessListener {
                            Log.d(TAG, "Allergy name updated successfully")
                            Toast.makeText(this, "Allergy name updated successfully", Toast.LENGTH_SHORT).show()
                            finish()
                        }
                        .addOnFailureListener { e ->
                            val errorMessage = "Error updating Allergy name: ${e.message}"
                            Log.e(TAG, errorMessage, e)
                            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                val errorMessage = "Error querying Allergies: ${e.message}"
                Log.e(TAG, errorMessage, e)
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
            }
    }

    private fun deleteDocument() {
        val oldName = selectedDocument

        db.collection(selectedCollection)
            .whereEqualTo("name", oldName)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    db.collection(selectedCollection).document(document.id)
                        .delete()
                        .addOnSuccessListener {
                            val successMessage = "Allergy with name '$oldName' was deleted successfully"
                            Log.d(TAG, successMessage)
                            Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show()
                            finish()
                        }
                        .addOnFailureListener { e ->
                            val errorMessage = "Error deleting Allergy: ${e.message}"
                            Log.e(TAG, errorMessage, e)
                            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                val errorMessage = "Error querying Allergies: ${e.message}"
                Log.e(TAG, errorMessage, e)
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
            }
    }



}
