package com.example.loginsystem
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.FirebaseFirestore
import java.security.MessageDigest

class loginpage : AppCompatActivity() {
    private val firestore = FirebaseFirestore.getInstance()
    private val usersCollection = firestore.collection("Users")
    private val admincollection = firestore.collection("Admin")
    companion object {
        var adminData: MutableList<String> = mutableListOf()
        var conditiondata: MutableList<String> = mutableListOf()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, loginpage::class.java)
        startActivity(intent)
        finish()
    }
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_loginpage)

        val loginButton = findViewById<MaterialButton>(R.id.LoginButton_id)
        val emailEditText = findViewById<EditText>(R.id.Email)
        val passwordEditText = findViewById<EditText>(R.id.editTextTextPassword)
        val adminbutton = findViewById<MaterialButton>(R.id.adminbutton)

        loginButton.setOnClickListener {
            val username = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                authenticateUser(username, password)
            } else {
                Toast.makeText(this@loginpage, "Please enter username and password", Toast.LENGTH_SHORT).show()
            }
        }
        adminbutton.setOnClickListener {
            val username = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                adminauthentication(username, password)

            } else {

                Toast.makeText(this@loginpage, "Please enter username and password", Toast.LENGTH_SHORT).show()
            }
        }

        val createAccountButton = findViewById<MaterialButton>(R.id.button2)
        createAccountButton.setOnClickListener {
            val intent = Intent(this@loginpage, signup::class.java)
            startActivity(intent)
        }
    }

    private fun adminauthentication(username: String, password: String) {
        admincollection
            .whereEqualTo("username", username)
            .whereEqualTo("password", hashPassword(password))
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    Toast.makeText(this@loginpage, "Invalid username or password", Toast.LENGTH_SHORT).show()
                } else {
                    adminData.clear()
                    for (document in documents) {
                        val adminusername = document.getString("username") ?: ""
                        val adminpassword = document.getString("password") ?: ""
                        val adminname = document.getString("fullname") ?: ""
                        adminData.add(adminusername)
                        adminData.add(adminpassword)
                        adminData.add(adminname)

                    }
                    Toast.makeText(this@loginpage, "Login Successful", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this@loginpage, Adminpage::class.java)
                    startActivity(intent)

                    adminData.forEachIndexed { index, data ->
                        Log.d("adminData", "Index $index: $data")
                    }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this@loginpage, "Authentication failed: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
    private fun authenticateUser(username: String, password: String) {
        usersCollection
            .whereEqualTo("username", username)
            .whereEqualTo("password", hashPassword(password))
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    Toast.makeText(this@loginpage, "Invalid username or password", Toast.LENGTH_SHORT).show()
                } else {
                    adminData.clear()
                    conditiondata.clear()

                    var conditionStatus = 0
                    val conditionsList = mutableListOf<String>()

                    for (document in documents) {
                        val userEmail = document.getString("username") ?: ""
                        val userPassword = document.getString("password") ?: ""
                        val fullName = document.getString("fullname") ?: ""
                        val userConditions = document.get("condition") as? List<String> ?: emptyList()
                        conditionStatus = document.getLong("conditionStatus")?.toInt() ?: 0

                        adminData.add(userEmail)
                        adminData.add(userPassword)
                        adminData.add(fullName)

                        conditionsList.addAll(userConditions)
                    }

                    conditiondata.addAll(conditionsList)

                    Toast.makeText(this@loginpage, "Login Successful", Toast.LENGTH_SHORT).show()

                    if (conditionStatus == 1) {
                        val intent = Intent(this@loginpage, Homepage::class.java)
                        startActivity(intent)
                    } else if (conditionStatus == 0) {
                        val intent = Intent(this@loginpage, selectCondition::class.java)
                        startActivity(intent)
                    }

                    adminData.forEachIndexed { index, data ->
                        Log.d("UserData", "Index $index: $data")
                    }

                    conditiondata.forEachIndexed { index, data ->
                        Log.d("ConditionData", "Index $index: $data")
                    }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this@loginpage, "Authentication failed: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }




    private fun hashPassword(password: String): String {
        val bytes = password.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("", { str, it -> str + "%02x".format(it) })
    }
}