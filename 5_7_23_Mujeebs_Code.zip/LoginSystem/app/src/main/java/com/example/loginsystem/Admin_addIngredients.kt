package com.example.loginsystem

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore
import kotlin.random.Random

class Admin_addIngredients : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var IngredientEditText: EditText
    private lateinit var IngredientListView: ListView
    private lateinit var IngredientsAdapter: IngredientAdapter

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_admin_add_ingredients)

        IngredientEditText = findViewById(R.id.ingtext)
        IngredientListView = findViewById(R.id.inglist)
        IngredientsAdapter = IngredientAdapter(this)

        val createConditionButton: Button = findViewById(R.id.createingbutton)
        createConditionButton.setOnClickListener {
            val Ingredientname = IngredientEditText.text.toString().trim()
            if (Ingredientname.isNotEmpty()) {
                checkIngredientExistence(Ingredientname)
            } else {
                Toast.makeText(this, "Please enter an Ingredient", Toast.LENGTH_SHORT).show()
            }
        }

        displaying()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, Adminpage::class.java)
        startActivity(intent)
        finish()
    }
    private fun checkIngredientExistence(Ingredientname: String) {
        db.collection("Harmful_Ingredients")
            .whereEqualTo("name", Ingredientname)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    createNewIng(Ingredientname)
                } else {
                    Toast.makeText(this, "Ingredient already exists", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createNewIng(Ingredientname: String) {
        val IngredientData = hashMapOf(
            "name" to Ingredientname
        )

        val randomId = Random.nextInt(1000000000)
        db.collection("Harmful_Ingredients")
            .document(randomId.toString())
            .set(IngredientData)
            .addOnSuccessListener {
                Toast.makeText(this, "Ingredient added successfully", Toast.LENGTH_SHORT).show()
                IngredientEditText.text.clear()
                displaying()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error adding Ingredient: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }



    private fun displaying() {
        db.collection("Harmful_Ingredients")
            .get()
            .addOnSuccessListener { documents ->
                val conditionList = mutableListOf<String>()
                for (document in documents) {
                    conditionList.add(document.getString("name") ?: "")
                }
                IngredientsAdapter.setData(conditionList)
                IngredientListView.adapter = IngredientsAdapter
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}