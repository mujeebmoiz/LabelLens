package com.example.loginsystem

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore

class selectedcollection : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var documentListView: ListView
    private lateinit var conditioncollection: String
    private lateinit var editdoc: Button
    private lateinit var adddoc: Button

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, ConditionsCollection::class.java)
        startActivity(intent)
        finish()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_selectedcollection)

        conditioncollection = ConditionsCollection.selectedCondition ?: ""

        var selectedDocumentName = ""

        fetchDocuments(conditioncollection)

        documentListView = findViewById(R.id.documentlist)

        documentListView.choiceMode = ListView.CHOICE_MODE_SINGLE

        documentListView.setOnItemClickListener { _, _, position, _ ->
            selectedDocumentName = documentListView.getItemAtPosition(position) as String
        }

        editdoc = findViewById(R.id.editdoc)

        adddoc = findViewById(R.id.addnedoc)

        editdoc.setOnClickListener {
            if (selectedDocumentName.isNotEmpty()) {
                Log.d("selectedcollection", "Selected document: $selectedDocumentName")
                Log.d("selectedcollection", "Selected condition: $conditioncollection")

                val intent = Intent(this, EditDocument::class.java)
                intent.putExtra("selectedDocumentName", selectedDocumentName)
                intent.putExtra("selectedCondition", conditioncollection)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please select a document", Toast.LENGTH_SHORT).show()
            }
        }
        adddoc.setOnClickListener {


                val intent = Intent(this, AddDocument::class.java)
                startActivity(intent)

        }
    }

    public fun fetchDocuments(collectionName: String) {
        db.collection(collectionName)
            .get()
            .addOnSuccessListener { documents ->
                val documentNames = mutableListOf<String>()
                for (document in documents) {
                    documentNames.add(document.getString("name") ?: "")
                }
                val documentAdapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_single_choice,
                    documentNames
                )
                documentListView.adapter = documentAdapter
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error getting documents: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
