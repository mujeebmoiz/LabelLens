package com.example.loginsystem

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore


class settings : AppCompatActivity() {
    private val firestore = FirebaseFirestore.getInstance()



    fun displayUserData() {
        val userData = loginpage.adminData
        val conditiondata = loginpage.conditiondata
        val fullname: TextView = findViewById(R.id.Settingsfull)
        val username: TextView = findViewById(R.id.settinguser)
        val condtion: TextView = findViewById(R.id.settingscondtion)

        fullname.text ="Name: ".plus(userData[2])
        username.text = "Username: ".plus(userData[0])
        condtion.text = "Condition: ".plus(conditiondata)

    }
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, Homepage::class.java)
        startActivity(intent)
        finish()
    }
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.setting_page)


        val backbutton: ImageButton = findViewById(R.id.backButton)

        displayUserData();

        backbutton.setOnClickListener {
            val intent = Intent(this@settings, Homepage::class.java)
            startActivity(intent)
        }


    }
}