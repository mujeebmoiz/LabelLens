package com.example.loginsystem;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class ocrcorrect extends AppCompatActivity {

    // UI Views
    private MaterialButton inputImageBtn;
    private MaterialButton recognizeTextBtn;

    private MaterialButton Scanbutton;
    private ShapeableImageView imageIv;
    private EditText recognizedTextEt;

    //c TAG
    private static final String TAG = "MAIN_TAG";

    //c Uri of image
    private Uri imageUri = null;

    //c handle result of camera/gallery permissions
    private static final int CAMERA_REQUEST_CODE = 100;
    private static final int STORAGE_REQUEST_CODE = 101;

    //c arrays of permission needed to pick image
    private String[] cameraPermissions;
    private String[] storagePermissions;

    //c progress dialog
    private ProgressDialog progressDialog;

    //c Text Recognizer
    private TextRecognizer textRecognizer;


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
        finish();
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.ocr_correct);

        //c initialize UI Views
        inputImageBtn = findViewById(R.id.inputImageBtn);
        recognizeTextBtn = findViewById(R.id.recognizeTextBtn);
        imageIv = findViewById(R.id.imageIv);
        recognizedTextEt = findViewById(R.id.recognizedTextEt);
        Scanbutton = findViewById(R.id.ScanButton);


        //c initialize the arrays of permissions from above
        cameraPermissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        storagePermissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

        //c initialize progress dialog to be shown while image is being recognized
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait");
        progressDialog.setCanceledOnTouchOutside(false);

        //c initialize Text Recognizer
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        //c handle click and show input image dialog
        inputImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInputImageDialog();
            }
        });

        //c handles click, start recognizing text from image
        recognizeTextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //c check if image is picked; check if imageUri is not null
                if (imageUri == null) {
                    //c imageURI is null => image hasn't been picked; need image to recognize text
                    Toast.makeText(ocrcorrect.this, "Error! Please Pick an Image!", Toast.LENGTH_SHORT).show();
                }
                //c imageURI is not null => image has been picked and text can be recognized
                else {
                    recognizeTextFromImage();
                }
            }
        });


        Scanbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String recognizedText = recognizedTextEt.getText().toString().replaceAll("(?m)^[ \t]*\r?\n", ""); // Remove leading newlines
                recognizedText = recognizedText.trim().toLowerCase();

                if (recognizedText.isEmpty()) {
                    Toast.makeText(ocrcorrect.this, "Please recognize text before proceeding", Toast.LENGTH_SHORT).show();
                    return;
                }

                String[] ingredientsArray = recognizedText.split("[,:().]\\s*");

                for (String ingredient : ingredientsArray) {
                    Log.d("Ingredients", ingredient);
                }

                Intent intent = new Intent(ocrcorrect.this, results.class);
                intent.putExtra("ingredientsArray", ingredientsArray);
                startActivity(intent);
            }
        });
    }

    private void recognizeTextFromImage() {
        Log.d(TAG, "recognizeTextFromImage: ");
        //c set message and show progress dialog
        progressDialog.setMessage("Preparing Image...");
        progressDialog.show();


        try {
            //c prepare input image using imageUri
            InputImage inputImage = InputImage.fromFilePath(this, imageUri);
            //c change progress message because image is prepared and we can start text recognition
            progressDialog.setMessage("Text Recognition in Progress...");
            //c start text recognition
            Task<Text> textTaskResult = textRecognizer.process(inputImage)
                    .addOnSuccessListener(new OnSuccessListener<Text>() {
                        @Override
                        public void onSuccess(Text text) {
                            //c text recognition process complete, dismiss progress dialog
                            progressDialog.dismiss();
                            //c get the recognized text from the image
                            String recognizedText = text.getText();
                            Log.d(TAG, "onSuccess: recognizedText: " + recognizedText);
                            //c set the recognized text to edit text
                            recognizedTextEt.setText(recognizedText);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            //c failed to recognize text from image, dismiss progress dialog and show reason
                            progressDialog.dismiss();
                            Log.e(TAG, "onFailure: ", e);
                            Toast.makeText(ocrcorrect.this, "Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } catch (Exception e) {
            //c exception while preparing input image
            progressDialog.dismiss();
            Log.e(TAG, "recognizeTextFromImage: ", e);
            Toast.makeText(this, "Failed to Prepare Image for Text Recognition due to " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    private void showInputImageDialog() {
        //c initialize pop up menu
        PopupMenu popupMenu = new PopupMenu(this, inputImageBtn);

        //c add camera and gallery to pop up menu
        popupMenu.getMenu().add(Menu.NONE, 1, 1, "CAMERA");
        popupMenu.getMenu().add(Menu.NONE, 2, 2, "GALLERY");

        popupMenu.show();

        //c handle pop up menu item clicks
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                //c get item id of the item clicked from pop up menu
                int id = menuItem.getItemId();
                if (id == 1) {
                    //c if camera is clicked, check if camera permissions are granted
                    Log.d(TAG, "onMenuItemClick: Camera Clicked");
                    if (checkCameraPermissions()) {
                        //c permissions granted, launch intent
                        pickImageCamera();
                    } else {
                        //c permissions not granted, request permissions
                        requestCameraPermissions();
                    }
                } else if (id == 2) {
                    //c if gallery is clicked, check if storage permissions are granted
                    Log.d(TAG, "onMenuItemClick: Galley Clicked");
                    if (checkCameraPermissions()) {
                        //c permissions granted, launch gallery intent
                        pickImageGallery();
                    } else {
                        //c storage permissions not granted, request permissions
                        requestStoragePermission();
                    }
                }
                return true;
            }
        });
    }

    private void pickImageGallery() {
        Log.d(TAG, "pickImageGalley: ");
        //c intent to pick image from gallery
        Intent intent = new Intent(Intent.ACTION_PICK);
        //c sets the type of file we want to pick
        intent.setType("image/*");
        galleryActivityResultLauncher.launch(intent);
    }

    private ActivityResultLauncher<Intent> galleryActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    //c receive image, if picked
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        //c image picked
                        Intent data = result.getData();
                        imageUri = data.getData();
                        Log.d(TAG, "onActivityResult: imageUri " + imageUri);

                        //c set to imageView
                        imageIv.setImageURI(imageUri);
                    } else {
                        Log.d(TAG, "onActivityResult: cancelled");
                        Toast.makeText(ocrcorrect.this, "Cancelled!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void pickImageCamera() {
        Log.d(TAG, "pickImageCamera: ");
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Sample Title");
        values.put(MediaStore.Images.Media.DESCRIPTION, "Sample Description");

        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        cameraActivityResultLauncher.launch(intent);
    }

    private ActivityResultLauncher<Intent> cameraActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    //receive image if taken from camera
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        //image is taken from camera; already have image in imageURI using pickImageCamera
                        Log.d(TAG, "onActivityResult: imageUri " + imageUri);
                        imageIv.setImageURI(imageUri);
                    } else {
                        //cancelled
                        Log.d(TAG, "onActivityResult: cancelled");
                        Toast.makeText(ocrcorrect.this, "Cancelled!", Toast.LENGTH_SHORT).show();
                    }

                }
            }
    );

    private boolean checkStoragePermission() {
        //c check if storage permission is allowed
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);

        return result;
    }

    private void requestStoragePermission() {
        //c request storage permission
        ActivityCompat.requestPermissions(this, storagePermissions, STORAGE_REQUEST_CODE);
    }

    private boolean checkCameraPermissions() {
        //c check if camera and storage permission are allowed
        boolean cameraResult = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == (PackageManager.PERMISSION_GRANTED);
        boolean storageResult = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);

//        return cameraResult;
        return cameraResult && storageResult;
    }

    private void requestCameraPermissions() {
        //c request camera permissions
        ActivityCompat.requestPermissions(this, cameraPermissions, CAMERA_REQUEST_CODE);
    }

    //c handle permission results

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        switch (requestCode) {
            case CAMERA_REQUEST_CODE: {
                //c check if an action from permission dialog is performed
                if (grantResults.length > 0) {
                    //check if camera and storage permissions are granted
                    boolean cameraAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    //c check if both permissions are granted
                    if (cameraAccepted && storageAccepted) {
                        if (cameraAccepted) {
                            //c if both permissions are granted, launch camera intent
                            pickImageCamera();
                        } else {
                            //c can't launch camera intent if one or both permissions are denied
                            Toast.makeText(this, "Camera Permissions Required", Toast.LENGTH_SHORT).show();
                        }
                    }
                    //cancelled
                    else {
                        Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            break;

            case STORAGE_REQUEST_CODE: {
                //c check if an action from permission dialog is performed
                if (grantResults.length > 0) {
//                    //c check if storage permissions are granted
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted) {
                        //storage permission is granted, can launch gallery intent
                        pickImageGallery();
                    }
//                    //c storage permission denied, can't launch gallery intent
                    else {
                        Toast.makeText(this, "Storage Permission Required to Access Gallery", Toast.LENGTH_SHORT).show();
                    }
                }

            }
            break;
        }
    }
}