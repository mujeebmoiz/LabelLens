package com.example.loginsystem

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore

class selectCondition : AppCompatActivity() {
    private lateinit var conditionListView: ListView
    private lateinit var firestore: FirebaseFirestore
    private lateinit var userData: List<String>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_condition)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        conditionListView = findViewById(R.id.conditionlistsignup)
        firestore = FirebaseFirestore.getInstance()

        userData = loginpage.adminData

        fetchConditions()

        val selectedConditionButton: Button = findViewById(R.id.selectedCondition)
        selectedConditionButton.setOnClickListener {
            val selectedConditions = (conditionListView.adapter as CheckBoxListAdapter).getCheckedItems()
            if (selectedConditions.isNotEmpty()) {
                updateUserData(selectedConditions)
            } else {
                Toast.makeText(
                    this@selectCondition,
                    "Please select at least one condition",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }



    private fun fetchConditions() {
        val conditionList = mutableListOf<String>()
        val adapter = CheckBoxListAdapter(this, conditionList)
        conditionListView.adapter = adapter

        firestore.collection("Conditions")
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val conditionName = document.getString("condition_name")
                    conditionName?.let { conditionList.add(it) }
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(
                    this,
                    "Error fetching conditions: ${exception.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    private fun updateUserData(selectedConditions: List<String>) {
        val userRef = firestore.collection("Users")
            .whereEqualTo("fullname", userData[2])
        userRef.get()
            .addOnSuccessListener { documents ->
                val conditionsList = mutableListOf<String>()
                for (document in documents) {
                    val userDocRef = firestore.collection("Users").document(document.id)
                    userDocRef.update(
                        mapOf(
                            "condition" to selectedConditions,
                            "conditionStatus" to 1
                        )
                    ).addOnSuccessListener {
                        conditionsList.addAll(selectedConditions)
                        loginpage.conditiondata.addAll(conditionsList)

                        val intent = Intent(this@selectCondition, Homepage::class.java)
                        startActivity(intent)


                    }.addOnFailureListener { e ->
                        Toast.makeText(
                            this@selectCondition,
                            "Error updating user conditions: ${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(
                    this,
                    "Error fetching user data: ${exception.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }
}