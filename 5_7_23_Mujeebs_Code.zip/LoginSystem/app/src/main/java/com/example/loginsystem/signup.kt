package com.example.loginsystem
import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore
import java.security.MessageDigest

class signup : AppCompatActivity() {

    private val firestore = FirebaseFirestore.getInstance()
    private val usersCollection = firestore.collection("Users")
    @SuppressLint("MissingInflatedId")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_signup)


        val button2 = findViewById<Button>(R.id.button)

        button2.setOnClickListener {
            val usernameEt = findViewById<EditText>(R.id.usernameEt)
            val passET = findViewById<EditText>(R.id.passET)
            val fullNameEt = findViewById<EditText>(R.id.fullname)
            val username = usernameEt.text.toString()
            val password = passET.text.toString()
            val fullName = fullNameEt.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty() && fullName.isNotEmpty()) {
                val passwordHash = hashPassword(password)

                val user = hashMapOf(
                    "username" to username,
                    "password" to passwordHash,
                    "fullname" to fullName,
                    "condition" to " ",
                    "conditionStatus" to 0
                )

                usersCollection.add(user)
                    .addOnSuccessListener { documentReference ->
                        Toast.makeText(
                            this@signup,
                            "Signup Successful",
                            Toast.LENGTH_SHORT
                        ).show()
                        val intent = Intent(this@signup, loginpage::class.java)
                        startActivity(intent)
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firestore", "Error adding user", exception)
                    }
            } else {
                Toast.makeText(this@signup, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
        val returnButton = findViewById<Button>(R.id.returnbutton)
        returnButton.setOnClickListener {
            val intent = Intent(this@signup, loginpage::class.java)
            startActivity(intent)
        }
    }
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, loginpage::class.java)
        startActivity(intent)
        finish()
    }

    private fun hashPassword(password: String): String {
        val bytes = password.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("", { str, it -> str + "%02x".format(it) })
    }
}
