package com.example.loginsystem

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.FirebaseFirestore

class AddDocument : AppCompatActivity() {
    private lateinit var Addcolecname: TextView

    private lateinit var documentNameEditText: EditText
    private lateinit var addButton: Button
    private lateinit var collectionName: String

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        collectionName = ConditionsCollection.selectedCondition
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_add_document)

        Addcolecname = findViewById(R.id.addcollecname)

        Addcolecname.text = "Condition Name: ".plus(collectionName)

        documentNameEditText = findViewById(R.id.Adddocname)

        addButton = findViewById(R.id.AddButton)

        addButton.setOnClickListener {
            addDocumentToDatabase()
            val intent = Intent(this@AddDocument, ConditionsCollection::class.java)
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, selectedcollection::class.java)
        startActivity(intent)
        finish()
    }
    private fun addDocumentToDatabase() {
        val documentName = documentNameEditText.text.toString()

        if (documentName.isNotEmpty()) {
            val db = FirebaseFirestore.getInstance()
            val documentData = hashMapOf(
                "name" to documentName
            )

            db.collection(collectionName)
                .add(documentData)
                .addOnSuccessListener(OnSuccessListener { documentReference ->
                    Toast.makeText(this, "Allergy added successfully", Toast.LENGTH_SHORT).show()
                })
                .addOnFailureListener(OnFailureListener { e ->
                    Toast.makeText(this, "Error adding Allergy: " + e.message, Toast.LENGTH_SHORT).show()
                })
        } else {
            Toast.makeText(this, "Please enter a Allergy name", Toast.LENGTH_SHORT).show()
        }
    }

}