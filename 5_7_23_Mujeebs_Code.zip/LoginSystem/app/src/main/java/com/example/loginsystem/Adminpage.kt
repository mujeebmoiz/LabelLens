package com.example.loginsystem


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class Adminpage : AppCompatActivity() {
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, loginpage::class.java)
        startActivity(intent)
        finish()
    }
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_adminpage)

        val AddCondition: LinearLayout = findViewById(R.id.addcondition)
        val ReadFeedback: LinearLayout = findViewById(R.id.readfeedback)
        val AddAllergy: LinearLayout = findViewById(R.id.addAllergy)
        val Adding: LinearLayout = findViewById(R.id.addIng)



        AddCondition.setOnClickListener {
            val intent = Intent(this@Adminpage, adminconditionsadd::class.java)
            startActivity(intent)
        }

        ReadFeedback.setOnClickListener {
            val intent = Intent(this@Adminpage, AdminFeedback::class.java)
            startActivity(intent)
        }

        AddAllergy.setOnClickListener {
            val intent = Intent(this@Adminpage, ConditionsCollection::class.java)
            startActivity(intent)
        }
        Adding.setOnClickListener {
            val intent = Intent(this@Adminpage, Admin_addIngredients::class.java)
            startActivity(intent)
        }

        }
    }
