package com.example.loginsystem

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore

class ConditionsCollection : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var collectionsListView: ListView

    companion object {
        var selectedCondition: String = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_admin_collection_view)

        collectionsListView = findViewById(R.id.collectionlist)

        fetchCollections()

        val selectCategoryButton: Button = findViewById(R.id.selectcategory)
        selectCategoryButton.setOnClickListener {
            if (selectedCondition.isNotEmpty()) {
                val intent = Intent(this@ConditionsCollection, selectedcollection::class.java)
                startActivity(intent)

                Log.d("ConditionsCollection", "Selected condition: $selectedCondition")
            } else {
                Toast.makeText(this, "Please select a condition", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, Adminpage::class.java)
        startActivity(intent)
        finish()
    }
    private fun fetchCollections() {
        db.collection("Conditions")
            .get()
            .addOnSuccessListener { documents ->
                val conditionNames = mutableListOf<String>()
                for (document in documents) {
                    conditionNames.add(document.getString("condition_name") ?: "")
                }
                val collectionsAdapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_single_choice,
                    conditionNames
                )
                collectionsListView.adapter = collectionsAdapter

                collectionsListView.setOnItemClickListener { _, _, position, _ ->
                    selectedCondition = conditionNames[position]
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error getting conditions: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
