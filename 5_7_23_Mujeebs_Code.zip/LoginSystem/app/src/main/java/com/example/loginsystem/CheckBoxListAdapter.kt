package com.example.loginsystem

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.TextView

class CheckBoxListAdapter (context: Context, private val items: List<String>) :

    ArrayAdapter<String>(context, R.layout.list_item_with_checkbox, items)
    {

        private val checkedPositions = mutableSetOf<Int>()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view: View = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.list_item_with_checkbox, parent, false)
            val textView = view.findViewById<TextView>(R.id.textView)
            val checkBox = view.findViewById<CheckBox>(R.id.checkBox)

            textView.text = items[position]

            checkBox.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    checkedPositions.add(position)
                } else {
                    checkedPositions.remove(position)
                }
            }
            checkBox.isChecked = checkedPositions.contains(position)

            return view
        }

        fun getCheckedItems(): List<String> {
            return checkedPositions.map { items[it] }
        }
    }

