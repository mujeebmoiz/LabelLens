package com.example.loginsystem

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.app.AlertDialog
import android.content.Intent
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate

import com.google.firebase.firestore.FirebaseFirestore

class AdminFeedback : AppCompatActivity() {

    private lateinit var firestore: FirebaseFirestore

    private lateinit var feedbackListView: ListView
    private lateinit var feedbackList: MutableList<FeedbackItem>
    private lateinit var feedbackAdapter: FeedbackAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_admin_feedback)

        firestore = FirebaseFirestore.getInstance()

        feedbackListView = findViewById(R.id.feedback_listView)
        feedbackList = mutableListOf()
        feedbackAdapter = FeedbackAdapter(this, feedbackList)
        feedbackListView.adapter = feedbackAdapter

        feedbackListView.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
                val feedbackItem = feedbackList[position]
                showFeedbackPopup(feedbackItem)
            }

        loadFeedbackData()
    }

    private fun loadFeedbackData() {
        firestore.collection("Feedback")
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val subject = document.getString("subject") ?: ""
                    val userName = document.getString("user_name") ?: ""
                    val status = document.getString("status") ?: ""
                    val feedback = document.getString("feedback") ?: ""
                    val feedbackItem = FeedbackItem(subject, userName, status, feedback)
                    feedbackList.add(feedbackItem)
                }
                feedbackAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "Error getting documents: ", exception)
            }
    }
    @SuppressLint("MissingInflatedId")
    private fun showFeedbackPopup(feedbackItem: FeedbackItem) {
        val dialogBuilder = AlertDialog.Builder(this)
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.popup_feedback, null)
        dialogBuilder.setView(dialogView)

        val textViewFeedback = dialogView.findViewById<TextView>(R.id.textViewSubject)
        val textViewUserName = dialogView.findViewById<TextView>(R.id.textViewUserName)
        val textViewStatus = dialogView.findViewById<TextView>(R.id.textViewStatus)
        val buttonAccept = dialogView.findViewById<Button>(R.id.buttonAccept)
        val buttonDeny = dialogView.findViewById<Button>(R.id.buttonDeny)

        textViewFeedback.text = "${feedbackItem.feedback}"
        textViewUserName.text = "${feedbackItem.userName}"
        textViewStatus.text = "${feedbackItem.status}"

        val alertDialog = dialogBuilder.create()

        buttonAccept.setOnClickListener {
            updateFeedbackStatus(feedbackItem, "Accepted")
            alertDialog.dismiss()
            finish()
        }

        buttonDeny.setOnClickListener {
            updateFeedbackStatus(feedbackItem, "Denied")
            alertDialog.dismiss()
            finish()
        }

        alertDialog.show()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, Adminpage::class.java)
        startActivity(intent)
        finish()
    }

    private fun updateFeedbackStatus(feedbackItem: FeedbackItem, newStatus: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("Feedback")
            .whereEqualTo("subject", feedbackItem.subject)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    // Update the status of each document found by the query
                    db.collection("Feedback").document(document.id)
                        .update("status", newStatus)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Feedback status updated successfully", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Error updating feedback status: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error querying Feedback: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    data class FeedbackItem(val subject: String, val userName: String, val status: String, val feedback: String)

    class FeedbackAdapter(
        private val context: Context,
        private val feedbackList: List<FeedbackItem>
    ) : BaseAdapter() {

        override fun getCount(): Int {
            return feedbackList.size
        }

        override fun getItem(position: Int): Any {
            return feedbackList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.feedback_item, parent, false)
            val feedbackItem = feedbackList[position]
            view.findViewById<TextView>(R.id.subjectTextView).text = feedbackItem.subject
            view.findViewById<TextView>(R.id.statusTextView).text = feedbackItem.status
            return view
        }
    }
}

