package com.example.loginsystem

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore


class results: AppCompatActivity() {


    private val db = Firebase.firestore
    private val conditiondata = loginpage.conditiondata
    private lateinit var ingredientsArray: Array<String>
    val harminglist = mutableListOf<String>()
    private lateinit var ingredientsAnaylsisbutton: Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_results)

        val backbutton: ImageButton = findViewById(R.id.feebackback)
        val conditionheader: TextView = findViewById(R.id.condition);
        ingredientsAnaylsisbutton = findViewById(R.id.IngredientsAnalysis)



        backbutton.setOnClickListener {
            val intent = Intent(this@results, ocrcorrect::class.java)
            startActivity(intent)
        }



        ingredientsAnaylsisbutton.setOnClickListener {
            val intent = Intent(this@results, IngredientAnalysis::class.java)
            startActivity(intent)
            intent.putStringArrayListExtra("harminglist", ArrayList(harminglist))
            startActivity(intent)
        }


        ingredientsArray = intent.getStringArrayExtra("ingredientsArray") ?: emptyArray()

        compareIngredientsWithDatabase()

        conditionheader.text = "For Your Diet"
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, ocrcorrect::class.java)
        startActivity(intent)
        finish()
    }
    @SuppressLint("SuspiciousIndentation")
    private fun compareIngredientsWithDatabase() {
        val ingredientsArray = intent.getStringArrayExtra("ingredientsArray") ?: emptyArray()

        val decision: TextView = findViewById(R.id.decision)
        val data: TextView = findViewById(R.id.Data)
        val harmfuling: TextView = findViewById(R.id.IngredientsName)
        val xicon1: ImageView = findViewById(R.id.xicon1)
        val checkicon1: ImageView = findViewById(R.id.Check1)
        val ingheader: TextView = findViewById(R.id.ingredientsheader)

        val allHarmfulIngredients = mutableListOf<String>()

        ingredientsArray.forEach { ingredient ->
            db.collection("Harmful_Ingredients")
                .whereEqualTo("name", ingredient)
                .get()
                .addOnSuccessListener { result ->
                    result.forEach { document ->
                        val harmfulIngredientName = document["name"] as? String
                        harmfulIngredientName?.let {
                            allHarmfulIngredients.add(it)
                            harminglist.add(it)

                        }
                    }
                }
        }

        conditiondata.forEach { conditionName ->
            ingredientsArray.forEach { ingredient ->
                db.collection(conditionName)
                    .whereEqualTo("name", ingredient)
                    .get()
                    .addOnSuccessListener { result ->
                        result.forEach { document ->
                            val conditionName = document["name"] as? String
                            conditionName?.let {
                                allHarmfulIngredients.add(it)
                            }
                        }


                        if (harminglist.isNotEmpty()){
                            ingredientsAnaylsisbutton.visibility = View.VISIBLE
                        }else{
                            ingredientsAnaylsisbutton.visibility = View.INVISIBLE

                        }
                        data.text = ingredientsArray.joinToString("\n")
                        val uniqueHarmfulIngredients = allHarmfulIngredients.toSet().toList()

                                if (uniqueHarmfulIngredients.isNotEmpty()) {
                                    decision.visibility = View.VISIBLE;
                                    harmfuling.visibility = View.VISIBLE;
                                    decision.text = "Found ${uniqueHarmfulIngredients.size} harmful ingredient(s)"
                                    data.setTextColor(resources.getColor(R.color.red))
                                    data.text = "Harmful to eat"
                                    data.visibility = View.VISIBLE
                                    xicon1.visibility = View.VISIBLE
                                    checkicon1.visibility = View.GONE
                                    harmfuling.text = uniqueHarmfulIngredients.joinToString("\n")
                                    ingheader.text = "Ingredients"
                                    ingheader.visibility = View.VISIBLE;
                                } else {

                                    decision.visibility = View.VISIBLE;
                                    decision.text = "No harmful triggers found"
                                    data.setTextColor(resources.getColor(R.color.green))
                                    data.text = "Safe to eat"
                                    xicon1.visibility = View.GONE
                                    data.visibility = View.VISIBLE
                                    checkicon1.visibility = View.VISIBLE
                                    harmfuling.visibility = View.INVISIBLE;
                                    ingheader.visibility = View.INVISIBLE;
                                }
                            }
                            .addOnFailureListener { exception ->
                                Log.d(ContentValues.TAG, "Error Getting Documents", exception)
                            }
                    }
            }
        }
    }
