package com.example.loginsystem

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.firestore.FirebaseFirestore
import kotlin.random.Random

class adminconditionsadd : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var conditionEditText: EditText
    private lateinit var conditionListView: ListView
    private lateinit var conditionAdapter: IngredientAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_adminconditionsadd)

        conditionEditText = findViewById(R.id.addcondtext)
        conditionListView = findViewById(R.id.conditionslist)
        conditionAdapter = IngredientAdapter(this)

        val createConditionButton: Button = findViewById(R.id.createconditionbutton)
        createConditionButton.setOnClickListener {
            val conditionName = conditionEditText.text.toString().trim()
            if (conditionName.isNotEmpty()) {
                checkConditionExistence(conditionName)
            } else {
                Toast.makeText(this, "Please enter a condition", Toast.LENGTH_SHORT).show()
            }
        }

        displayConditions()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, Adminpage::class.java)
        startActivity(intent)
        finish()
    }
    private fun checkConditionExistence(conditionName: String) {
        db.collection("Conditions")
            .whereEqualTo("condition_name", conditionName)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    createNewCondition(conditionName)
                } else {
                    Toast.makeText(this, "Condition already exists", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createNewCondition(conditionName: String) {
        val conditionData = hashMapOf(
            "condition_name" to conditionName
        )

        val randomId = Random.nextInt(1000000000)
        db.collection("Conditions")
            .document(randomId.toString())
            .set(conditionData)
            .addOnSuccessListener {
                Toast.makeText(this, "Condition added successfully", Toast.LENGTH_SHORT).show()
                createNewCollection(conditionName)
                conditionEditText.text.clear()
                displayConditions()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createNewCollection(conditionName: String) {
        db.collection(conditionName).document("sampleDoc").set(hashMapOf("sampleField" to "sampleValue"))
            .addOnSuccessListener {
                Toast.makeText(this, "New collection created for $conditionName", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun displayConditions() {
        db.collection("Conditions")
            .get()
            .addOnSuccessListener { documents ->
                val conditionList = mutableListOf<String>()
                for (document in documents) {
                    conditionList.add(document.getString("condition_name") ?: "")
                }
                conditionAdapter.setData(conditionList)
                conditionListView.adapter = conditionAdapter
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}