package com.example.loginsystem
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class IngredientAdapter(context: Context) : ArrayAdapter<String>(context, 0) {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var ingredientList = listOf<String>()

    fun setData(ingredients: List<String>) {
        ingredientList = ingredients
        notifyDataSetChanged()
    }

    override fun getCount(): Int {
        return ingredientList.size
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        val holder: ViewHolder
        if (view == null) {
            view = inflater.inflate(R.layout.ingredient_item, parent, false)
            holder = ViewHolder(view)
            view.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }

        val ingredient = ingredientList[position]
        holder.ingredientTextView.text = ingredient

        return view!!
    }

    private class ViewHolder(view: View) {
        val ingredientTextView: TextView = view.findViewById(R.id.ingredientTextView)
    }

}