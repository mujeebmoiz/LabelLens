package com.example.loginsystem
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.FirebaseFirestore

class IngredientAnalysis : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var db: FirebaseFirestore
    private lateinit var ingredientsArray: Array<String>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_ingredient_analysis)

        listView = findViewById(R.id.HarmfulIngList)
        db = FirebaseFirestore.getInstance()

        ingredientsArray = intent.getStringArrayExtra("ingredientsArray") ?: emptyArray()
        val harminglist = intent.getStringArrayListExtra("harminglist") ?: ArrayList()

        populateListView(harminglist)
    }


    private fun populateListView(harminglist: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, harminglist)
        listView.adapter = adapter

        listView.setOnItemClickListener { parent, view, position, id ->
            val selectedIngredient = parent.getItemAtPosition(position) as String
            showIngredientDialog(selectedIngredient)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

    private fun showIngredientDialog(ingredient: String) {
        db.collection("Harmful_Ingredients")
            .whereEqualTo("name", ingredient)
            .get()
            .addOnSuccessListener { result ->
                if (result.isEmpty) {
                    // Ingredient not found in harmful ingredients database
                    val defaultMessage = "This ingredient is not harmful."
                    showDialogWithMessage(ingredient, defaultMessage)
                } else {
                    result.forEach { document ->
                        val message = document.getString("message") ?: "No message available"
                        showDialogWithMessage(ingredient, message)
                    }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }


    private fun showDialogWithMessage(ingredient: String, message: String) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.popup_harmfuling, null)
        val dialogBuilder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setTitle("Harmful Ingredient")

        val ingNameTextView = dialogView.findViewById<TextView>(R.id.ingname)
        val messageTextView = dialogView.findViewById<TextView>(R.id.message)

        ingNameTextView.text = ingredient
        messageTextView.text = message

        dialogBuilder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog = dialogBuilder.create()
        dialog.show()
    }



}